<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Vue Test</title>
</head>
<body>

<div id="app">

<router-link to="/">Homepage</router-link> <br>
<example></example>

</div>


<script>
window.Laravel = <?php echo json_encode([ 'csrf_token' => csrf_token()]); ?>
</script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
	
</body>
</html>