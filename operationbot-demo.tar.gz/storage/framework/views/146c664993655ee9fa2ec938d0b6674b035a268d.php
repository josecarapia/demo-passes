<!-- footer start -->
    <footer id="footer" class="solid-bg">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <div class="social-icon">
             <a href="http://facebook.com/operationbot" class="wow rollIn animated" data-wow-delay=".1s"><i class="fa fa-facebook"></i></a>
             <a href="https://twitter.com/opbeontime" class="wow rollIn animated" data-wow-delay=".2s"><i class="fa fa-twitter"></i></a>
             <a href="https://plus.google.com/u/3/106111170751312122794/" class="wow rollIn animated" data-wow-delay=".3s"><i class="fa fa-google-plus"></i></a>
            </div> 
            <div class="copyright">
              <p>&copy; <span>Operation BOT</span>2016</p>
              <p>Created by <span><a href="http://trigenresults.com">Trigen Results</a></span></p>
            </div>
          </div>
        </div>   
      </div> 
      <div id="go-to-top">
          <a href="#banner"></a>
      </div>
      <!--/.go-to-top end-->    
    </footer>
    <!-- footer end -->