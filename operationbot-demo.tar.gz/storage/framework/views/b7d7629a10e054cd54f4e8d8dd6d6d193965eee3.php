<!doctype>
<html>
<head>
	<title>
		<?php if (! empty(trim($__env->yieldContent('title')))): ?>
			<?php echo $__env->yieldContent('title'); ?> - OpBOT
		<?php else: ?>
			Operation BOT
		<?php endif; ?>
	</title>
	<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</div>

	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>