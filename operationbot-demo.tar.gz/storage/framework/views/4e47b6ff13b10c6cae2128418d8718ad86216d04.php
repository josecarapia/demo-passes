<!-- video start -->
    <section id="video" class="video solid-bg">
      <div class="video-container"><div id="player"></div><div class="video-mask"></div></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <div class="video-mask">
              <h2 class="wow bounceInDown">how it works</h2>
				<a href="https://www.youtube.com/watch?v=LAXBJxxX-lE" class="play wow animated"></a>
              <span class="wow bounceInUp">watch video</span>
            </div>            
          </div>
        </div>
      </div>
    </section>
    <!-- video end -->