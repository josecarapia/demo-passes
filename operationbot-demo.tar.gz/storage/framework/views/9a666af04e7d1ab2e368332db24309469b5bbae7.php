				<ul class="nav navbar-nav">
                  <li><a href="#description">About</a></li>
                  <li><a href="#about">Features</a></li>
                  <li><a href="#screenshots">Screenshots</a></li>
                  <li><a href="#subscription">Request Info</a></li>
                  <li><a href="#contact">Contact</a></li>
                </ul>