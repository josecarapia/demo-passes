<?php $__env->startSection('title', 'Operation BOT'); ?>
<?php $__env->startSection('description', 'Operation BOT by Trigen Results'); ?>
<?php $__env->startSection('author', 'Operation BOT'); ?>



<?php $__env->startSection('content'); ?>

   


    <?php echo $__env->make('pages.home.description', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('pages.home.video', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('pages.home.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->make('pages.home.features', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    

    <?php echo $__env->make('pages.home.subscription', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('pages.home.contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.home.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>