<!-- support start -->
    <section id="support" class="support white">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <span class="sub-head wow fadeInLeft">stay close</span>
            <div class="title wow fadeInRight">
              <h2>help & support</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-4 wow bounceInUp" data-wow-duration="1s">
            <div class="support-block">
              <span class="support-icon"><i class="fa fa-bitbucket"></i></span>
              <h3>Product Support</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim</p>
            </div>
          </div>
          <div class="col-sm-4 wow bounceInUp" data-wow-duration="2s">
            <div class="support-block active">
              <span class="support-icon"><i class="fa fa-bullhorn"></i></span>
              <h3>Product Support</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim</p>
            </div>
          </div>
          <div class="col-sm-4 wow bounceInUp" data-wow-duration="3s">
            <div class="support-block">
              <span class="support-icon"><i class="fa fa-stethoscope"></i></span>
              <h3>Product Support</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- support end --> 