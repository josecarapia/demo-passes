<!-- review start -->
    <section id="review" class="review solid-bg">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h2 class="wow swing">Testimonials</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 text-center">
            <div id="myCarousel1" class="carousel slide" data-ride="carousel">
              <div class="carousel-inner">
                <div class="active item">
                  <span class="review-img">
                     <img src="{{ asset('images/site/thumb-1.png') }}" alt="image">
                   </span>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                  <span class="reviewer-name">Maria Jones</span>
                  <span class="review-comp">CEO, GRAPE Ltd.</span>
                </div>
                <div class="item">
                  <span class="review-img">
                     <img src="{{ asset('images/site/thumb-1.png') }}" alt="image">
                   </span>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                  <span class="reviewer-name">Maria Jones</span>
                  <span class="review-comp">CEO, GRAPE Ltd.</span>
                </div>
                <div class="item">
                  <span class="review-img">
                     <img src="{{ asset('images/site/thumb-1.png') }}" alt="image">
                   </span>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                  <span class="reviewer-name">Maria Jones</span>
                  <span class="review-comp">CEO, GRAPE Ltd.</span>
                </div>
              </div>
              <!-- Carousel nav -->
              <a class="carousel-control left" href="#myCarousel1" data-slide="prev"><i class="fa fa-angle-left"></i></a>
              <a class="carousel-control right" href="#myCarousel1" data-slide="next"><i class="fa fa-angle-right"></i></a>              
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- review end -->