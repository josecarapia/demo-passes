<!-- download start -->
    <section id="download" class="downlaod solid-bg">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 text-center">
              <h2 class="wow swing">download</h2>
              <p>Lorem ipsum dolor sit amet lorem ipsum dolor sit amet</p>
              <span class="wow fadeInLeft" style="display:inline-block"><a href="" class="btn"><i class="fa fa-apple"></i> app store</a></span>
              <span class="wow fadeInLeft" style="display:inline-block"><a href="" class="btn"><i class="fa fa-android"></i> play store</a></span>
              <span class="wow fadeInLeft" style="display:inline-block"><a href="" class="btn"><i class="fa fa-windows"></i> windows</a></span>
            </div>
          </div>
        </div>
    </section>
    <!-- download end -->