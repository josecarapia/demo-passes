@extends('pages.home.layout')

@section('title', 'Operation BOT')




@section('content')
asdf
@stop