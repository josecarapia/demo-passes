<!-- screenshot start -->
    <section id="screenshots" class="screenshot white">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <span class="sub-head wow fadeInLeft">take a look</span>            
            <div class="title wow fadeInRight">
              <h2>screenshots</h2>
            </div>
            <div id="owl-demo" class="owl-carousel">
                <div class="item screenshot-block">
                  <img src="{{ asset('images/site/screenshot.jpg') }}" alt="GRAPE">
                  <div class="caption">
                    <a class="test-popup-link" href="{{ asset('images/site/screenshot.jpg') }}"><i class="fa fa-plus"></i></a>
                  </div>
                </div>
                <div class="item screenshot-block">
                  <img src="{{ asset('images/site/screenshot.jpg') }}" alt="GRAPE">
                  <div class="caption">
                    <a class="test-popup-link" href="{{ asset('images/site/screenshot.jpg') }}"><i class="fa fa-plus"></i></a>
                  </div>
                </div>
                <div class="item screenshot-block">
                  <img src="{{ asset('images/site/screenshot.jpg') }}" alt="GRAPE">
                  <div class="caption">
                    <a class="test-popup-link" href="{{ asset('images/site/screenshot.jpg') }}"><i class="fa fa-plus"></i></a>
                  </div>
                </div>
                <div class="item screenshot-block">
                  <img src="{{ asset('images/site/screenshot.jpg') }}" alt="GRAPE">
                  <div class="caption">
                    <a class="test-popup-link" href="{{ asset('images/site/screenshot.jpg') }}"><i class="fa fa-plus"></i></a>
                  </div>
                </div>
                <div class="item screenshot-block">
                  <img src="{{ asset('images/site/screenshot.jpg') }}" alt="GRAPE">
                  <div class="caption">
                    <a class="test-popup-link" href="{{ asset('images/site/screenshot.jpg') }}"><i class="fa fa-plus"></i></a>
                  </div>
                </div>
                <div class="item screenshot-block">
                  <img src="{{ asset('images/site/screenshot.jpg') }}" alt="GRAPE">
                  <div class="caption">
                    <a class="test-popup-link" href="{{ asset('images/site/screenshot.jpg') }}"><i class="fa fa-plus"></i></a>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </section>
    <!-- screenshot end -->