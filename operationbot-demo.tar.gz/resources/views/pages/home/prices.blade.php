    <!-- price start -->
    <section id="price" class="pricingtable-section white">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <span class="sub-head wow fadeInLeft">are you surrprised</span>            
            <div class="title wow fadeInRight">
              <h2>unbelievable price</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-4 wow bounceInUp" data-wow-duration="1s">
            <div class="price-block">
              <div class="price-header">
                <h3>free plan</h3>
                <i class="fa fa-heart"></i>
              </div>
              <div class="price-plan">
                <ul>
                  <li>
                    <span class="price">$0.00</span>
                    <span class="month">/per month</span>
                  </li>
                  <li>Unlimited Space</li>
                  <li>Unlimited Database</li>
                  <li>Easy to Istall</li>
                  <li>Unlimited Subdomains</li>
                  <li>Dedicated Serer</li>
                  <li> <a href="" class="btn">sign up</a></li>
                </ul>
              </div>
            </div>
            <!-- /.price-block -->
          </div>
          <div class="col-sm-4 wow bounceInUp" data-wow-duration="2s">
            <div class="price-block active">
              <div class="price-header">
                <h3>basic plan</h3>
                <i class="fa fa-cogs"></i>
              </div>
              <div class="price-plan">
                <ul>
                  <li>
                    <span class="price">$9.00</span>
                    <span class="month">/per month</span>
                  </li>
                  <li>Unlimited Space</li>
                  <li>Unlimited Database</li>
                  <li>Easy to Istall</li>
                  <li>Unlimited Subdomains</li>
                  <li>Dedicated Serer</li>
                  <li> <a href="" class="btn">sign up</a></li>
                </ul>
              </div>
            </div>
            <!-- /.price-block -->
          </div>
          <div class="col-sm-4 wow bounceInUp" data-wow-duration="3s">
            <div class="price-block">
              <div class="price-header">
                <h3>developer plan</h3>
                <i class="fa fa-suitcase"></i>
              </div>
              <div class="price-plan">
                <ul>
                  <li>
                    <span class="price">$29.00</span>
                    <span class="month">/per month</span>
                  </li>
                  <li>Unlimited Space</li>
                  <li>Unlimited Database</li>
                  <li>Easy to Istall</li>
                  <li>Unlimited Subdomains</li>
                  <li>Dedicated Serer</li>
                  <li> <a href="" class="btn">sign up</a></li>
                </ul>
              </div>
            </div>
            <!-- /.price-block -->
          </div>
        </div>
      </div>
    </section>
    <!-- price end -->